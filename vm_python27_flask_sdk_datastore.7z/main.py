from flask import Flask
import data_store_proxy

app = Flask(__name__)


@app.route('/')
def hello_world():
    return 'Hello World!'


@app.route('/write_yes')
def write_yes():
    return 'yes'

@app.route('/insert_cop')
def insert_cop():
    data_store_proxy.insert()
    return 'inserted'

if __name__ == '__main__':
    app.run()
