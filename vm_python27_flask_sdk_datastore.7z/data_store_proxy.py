from __future__ import absolute_import, division, print_function
from google.appengine.ext import ndb


class Cop(ndb.Model):
    name = ndb.StringProperty()


def insert():
    Cop(name="Steve").put()
